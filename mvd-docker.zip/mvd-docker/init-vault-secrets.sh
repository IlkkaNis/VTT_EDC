#!/usr/bin/env bash
set -e

for VAULT in mvd-docker-consumer-vault-1 mvd-docker-provider-vault-1; do
  sudo docker exec -it $VAULT sh -c '
    export VAULT_ADDR=http://127.0.0.1:8200
    export VAULT_TOKEN=root
    vault kv put secret/controlplane-secret value=controlplane-secret
    vault kv put secret/sts-client-secret value=controlplane-secret
  '
done

echo "✔ Vault initialized for Identity Hub STS"