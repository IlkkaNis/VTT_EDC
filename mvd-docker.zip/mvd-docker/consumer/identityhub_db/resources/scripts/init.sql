CREATE USER identity WITH PASSWORD 'identity';
CREATE DATABASE identity OWNER identity;
