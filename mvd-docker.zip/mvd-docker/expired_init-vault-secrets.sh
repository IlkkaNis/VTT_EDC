#!/usr/bin/env bash
set -e

PROVIDER_DID="did:web:provider-identityhub%3A7093"
CONSUMER_DID="did:web:consumer-identityhub%3A7083"

PROVIDER_SECRET="provider-sts-secret"
CONSUMER_SECRET="consumer-sts-secret"

echo "=== Writing legacy sts-client-secret (kept for compatibility) ==="

sudo docker exec -it mvd-docker-provider-vault-1 \
  sh -c 'export VAULT_ADDR=http://127.0.0.1:8200 VAULT_TOKEN=root && \
         vault kv put secret/sts-client-secret value=controlplane-secret'

sudo docker exec -it mvd-docker-consumer-vault-1 \
  sh -c 'export VAULT_ADDR=http://127.0.0.1:8200 VAULT_TOKEN=root && \
         vault kv put secret/sts-client-secret value=controlplane-secret'


echo "=== Writing PARTICIPANT-SCOPED STS CLIENT SECRETS ==="

sudo docker exec -it mvd-docker-provider-vault-1 \
  sh -c "export VAULT_ADDR=http://127.0.0.1:8200 VAULT_TOKEN=root && \
         vault kv put secret/${PROVIDER_DID}-sts-client-secret value=${PROVIDER_SECRET}"

sudo docker exec -it mvd-docker-consumer-vault-1 \
  sh -c "export VAULT_ADDR=http://127.0.0.1:8200 VAULT_TOKEN=root && \
         vault kv put secret/${CONSUMER_DID}-sts-client-secret value=${CONSUMER_SECRET}"


echo "=== Writing dataplane private/public keys to PROVIDER Vault ==="

sudo docker exec -it mvd-docker-provider-vault-1 \
  sh -c 'export VAULT_ADDR=http://127.0.0.1:8200 VAULT_TOKEN=root && \
         vault kv put secret/dataplane-private-key value=dummy-private && \
         vault kv put secret/dataplane-public-key value=dummy-public'


echo "=== Writing dataplane private/public keys to CONSUMER Vault ==="

sudo docker exec -it mvd-docker-consumer-vault-1 \
  sh -c 'export VAULT_ADDR=http://127.0.0.1:8200 VAULT_TOKEN=root && \
         vault kv put secret/dataplane-private-key value=dummy-private && \
         vault kv put secret/dataplane-public-key value=dummy-public'


echo "=== All secrets written successfully! ==="